import pandas as pd


# Função para carregar os dados
def load_data():
    print('entrei')
    df = pd.read_csv('alunos_pii_none.csv', low_memory=False)
    df.head()
    return df

# Função para agrupar os dados semelhantes
def group_similar_categories(df):
    similar_groups = {
        'Pós graduação': ['Pós graduação', 'MBA', 'Mestrado', 'Pós-graduação'],
        'Ensino Superior': ['Superior Completo', 'Graduação'],
        'Ensino Médio': ['Ensino Médio Completo'],
        'Ensino Fundamental': ['Ensino Fundamental Completo', 'Fundamental'],
        'Outros': ['Outro', 'Não Especificado']
    }
    for new_category, categories in similar_groups.items():
        print(new_category)
        print(categories)
        df['Escolaridade'] = df['Escolaridade'].replace(categories, new_category)
    return df



alunos_df = load_data()
# alunos_df.head()

# new_alunos_df = group_similar_categories(alunos_df)

# new_alunos_df['Escolaridade'].head()